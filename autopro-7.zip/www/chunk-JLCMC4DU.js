import{b as a,c as b}from"./chunk-YJ5TA4PT.js";import"./chunk-VBFW7A5V.js";export{a as GESTURE_CONTROLLER,b as createGesture};
